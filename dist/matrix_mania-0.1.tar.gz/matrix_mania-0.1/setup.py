from setuptools import setup

setup(name='matrix_mania',
      version='0.1', 
      description='Basic Matrix Operations',
      packages=['matrix_mania'],
      author='Grant Gasser',
      author_email='glgasser@gmail.com',
      zip_safe = False)