# Matrix Mania
This project is being done as a personal introduction to creating Python packages and making them available with PyPi.

### Author: Grant Gasser

# Files 

# Installation
